// Copyright 2023 Samsung Electronics Co., Ltd. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef FIREBASE_APP_CLIENT_CPP_SRC_VERSION_TIZEN_H_
#define FIREBASE_APP_CLIENT_CPP_SRC_VERSION_TIZEN_H_

#define FIREBASE_SDK_TIZEN_VERSION "2.0.1"

#endif  // FIREBASE_APP_CLIENT_CPP_SRC_VERSION_TIZEN_H_
